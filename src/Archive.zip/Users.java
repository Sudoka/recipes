import java.util.ArrayList;


public class Users {

	String username;
	String password;
	boolean admin;
	ArrayList<String> recipes = new ArrayList<String>();
	
	public Users (String name) {
		this.username = name;
		this.password  = password;
		//recipesAdded=0;
	}
	
	boolean checkPass(String s) {
		if (s.equals(password)) {
			return true;
		}
		else return false;
	}
	
	
	
	
}
