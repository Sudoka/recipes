import javax.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.*;

public class Start extends JFrame {

	boolean loggedin;

	public Start() throws IOException {
		loggedin = false;
	}

	int numUsers = 0;

	String[] usernames = new String[100];
	String[] passwords = new String[100];

	private void login(String username, String password) {
		for (int i = 0; i < 100; i++) {
			if (usernames[i] == username) {
				if (passwords[i] == password) {
					loggedin = true;
				} else {
					System.out.println("Bad password");

				}
			} else {
				System.out.println("User not found");
			}
		}
	}

	private void createAccount(String user, String pass) {
		usernames[numUsers] = user;
		passwords[numUsers] = pass;
		numUsers++;
	}


	/*
	 * public void createRecipe() throws IOException { BufferedReader reader;
	 * reader = new BufferedReader(new InputStreamReader(System.in));
	 * System.out.println("Name of recipe?"); String name = reader.readLine();
	 * System.out.println("List ingredients"); ArrayList<String> ingredients =
	 * new ArrayList<String>(); String ingredient; ingredient =
	 * reader.readLine(); while (ingredient != "") {
	 * ingredients.add(ingredient); //ingredient = reader.readLine(); ingredient
	 * = } Recipe newRec = new Recipe(name, ingredients);
	 * System.out.println("Done"); }
	 */
	
	public static void draw() {

	}

	/*
	  public void addRecipe() throws IOException {
	
		
		System.out.println("List your ingredients, seperated by an enter. Press enter when done.");
		Scanner scan = new Scanner(System.in);
		String name = scan.nextLine();
		String input = scan.nextLine();
		ArrayList<String> ingredients = new ArrayList<String>();
		do {
			ingredients.add(input);
			// System.out.println(input);
			input = scan.nextLine();
		} while (!input.equals(""));
		Recipe newRec = new Recipe(name, ingredients);
		recipes.add(newRec);
		numRecipe++;
	}
	*/
	
	public static void main(String args[]) throws IOException {
		Start mainDisplay = new Start();
		RecipeController RC = new RecipeController();
		
		
		ArrayList<String> testIngredients = new ArrayList<String>();
		testIngredients.add("Ingredient1");
		testIngredients.add("Ingredient2");
		Recipe testRec = new Recipe("TestRec1", testIngredients);
		RC.addRecipe(testRec);
		
		// tests initialization, adding ingredients
		if(RC.getRecipe(testRec).ingredients.toArray()[0].equals("Ingredient1")) {
			System.out.println("Equaled!");
		}
		else {
			System.out.println("Did not equal");
		}
		
		// tests getingredients method and to make sure toArray() works
		if(RC.getRecipe(testRec).getIngredients().toArray()[0].equals("Ingredient1")) {
			System.out.println("Equaled!");	
		}
		else {
			System.out.println("Did not equal");
		}
		
		//tests if recipe has been saved to a text file properly
		FileReader input = new FileReader("TestRec1.txt");
		BufferedReader bufRead = new BufferedReader(input);
		String line = bufRead.readLine();
		if(line.equals("TestRec1")) {
			System.out.println("Equaled!");
		}
		else {
			System.out.println("Did not equal");
		}
		
	}

	static class Action implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			JFrame loginFrame = new JFrame("Login");
			loginFrame.setSize(350, 350);
			JPanel loginPanel = new JPanel(new GridBagLayout());
			loginFrame.getContentPane().add(loginPanel, BorderLayout.NORTH);
			GridBagConstraints c = new GridBagConstraints();
			JLabel loginHeader = new JLabel("Login");
			c.gridx = 0;
			c.gridy = 0;
			c.gridwidth = 2;
			loginPanel.add(loginHeader, c);
			JLabel usernameLabel = new JLabel("Username: ");
			c.gridwidth = 1;
			c.gridx = 0;
			c.gridy = 1;
			loginPanel.add(usernameLabel, c);
			JTextField user = new JTextField("", 10);
			c.gridx = 1;
			c.gridy = 1;
			loginPanel.add(user, c);
			c.gridy = 2;
			c.gridx = 0;
			JLabel passwordLabel = new JLabel("Password: ");
			loginPanel.add(passwordLabel, c);
			JTextField pass = new JTextField("", 10);
			c.gridy = 2;
			c.gridx = 1;
			loginPanel.add(pass, c);
			loginPanel.add(usernameLabel);
			loginFrame.setVisible(true);
		}
	}
}